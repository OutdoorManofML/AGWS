"""
Greedy Word Swap with Word Importance Ranking
===================================================


When WIR method is set to ``unk``, this is a reimplementation of the search
method from the paper: Is BERT Really Robust?

A Strong Baseline for Natural Language Attack on Text Classification and
Entailment by Jin et. al, 2019. See https://arxiv.org/abs/1907.11932 and
https://github.com/jind11/TextFooler.
"""


from torch.nn.functional import softmax
from textattack.goal_function_results import GoalFunctionResultStatus
from textattack.search_methods import SearchMethod
from textattack.shared.validators import (
    transformation_consists_of_word_swaps_and_deletions,
)
from abc import ABC, abstractmethod
from collections import defaultdict
import os
import numpy as np
import torch
from textattack.shared import utils
from textattack.shared import AttackedText
import operator
from textattack.constraints.semantics.sentence_encoders import UniversalSentenceEncoder
import random


class AdaptiveGradientbasedAttack(SearchMethod):
    """
        The source code of the paper ‘Adaptive Gradient-based Word Saliency for Adversarial Text Attacks’
    """

    def __init__(self, wir_method="adaptive gradient-based word saliency"):
        self.wir_method = wir_method
        self.lmd = 0.5
        self.eps = 10

    def gradient_based_order(self, initial_text):
        """Returns word indices of ``initial_text`` in descending order of
        importance."""
        len_text = len(initial_text.words)
        victim_model = self.get_victim_model()
        gradient_scores = np.zeros(initial_text.num_words)
        grad_output = victim_model.get_grad(initial_text.tokenizer_input)
        gradient = grad_output["gradient"]
        word2token_mapping = initial_text.align_with_model_tokens(victim_model)
        for i, word in enumerate(initial_text.words):
            matched_tokens = word2token_mapping[i]
            if not matched_tokens:
                gradient_scores[i] = 0.0
            else:
                ave_grad = np.mean(gradient[matched_tokens], axis=0)
                gradient_scores[i] = np.linalg.norm(ave_grad, ord=2)

        index_scores = gradient_scores
        search_over = False
        index_order = (-index_scores).argsort()
        return index_order, search_over

    # the evaluation function
    def object_function(self, x):
        re = []
        for j in range(len(x)):
            result, _ = self.get_goal_results([x[j]])
            pre_score = 1 - result[0].score
            if 'modified_indices' in x[j].attack_attrs:
                modified_words = len(x[j].attack_attrs['modified_indices'])
                modified_score = 1 - (modified_words / len(x[j].words))
                fitness = pre_score + self.lmd * modified_score
            else:
                fitness = pre_score
            tup = (fitness, result)
            re.append(tup)
        return re

    def perform_search(self, initial_result):
        n = len(initial_result.attacked_text.words)
        max_iter = n

        # Sort words by order of importance
        attacked_text = initial_result.attacked_text
        index_order, search_over = self.gradient_based_order(attacked_text)
        i = 0

        # initial result
        cur_result = initial_result
        best_result_score = self.object_function([initial_result.attacked_text])[0][0]
        best_result = self.object_function([initial_result.attacked_text])[0][1][0]
        # attack procedure
        while i < max_iter and not search_over:
            # Neighbor create
            transformed_text_candidates = self.get_transformations(
                cur_result.attacked_text,
                original_text=initial_result.attacked_text,
                indices_to_modify=[index_order[i]],
            )
            i += 1
            if len(transformed_text_candidates) == 0:
                continue
            # apply a local search to find a best solution in the i-th neighbors
            re = self.object_function(transformed_text_candidates)
            new_re = sorted(re, key=lambda x: x[0], reverse=True)
            new_re_best = new_re[0]
            cur_result = new_re_best[1][0]
            cur_score = new_re_best[0]
            if cur_score - best_result_score > 0:
                best_result = cur_result
                best_result_score = cur_score
            # checking if there exist adversarial examples
            if best_result.goal_status == GoalFunctionResultStatus.SUCCEEDED:
                return best_result
            cnt = 0
            # apply Variable Neighborhood Search to find a better solution
            while cnt < self.eps:
                cnt += 1
                # the shake operation on a solution
                random_index = random.randint(0, n-1)
                # avoid repeated modification
                if random_index == i:
                    continue
                else:
                    new_neighbor = self.get_transformations(
                        cur_result.attacked_text,
                        original_text=initial_result.attacked_text,
                        indices_to_modify=[index_order[random_index]],
                    )
                    if len(new_neighbor) == 0:
                        continue
                    else:
                        new_neighbor_candidate = random.choice(new_neighbor)
                        neighbor_re = self.object_function([new_neighbor_candidate])
                        neighbor_cur_score = neighbor_re[0][0]
                        neighbor_cur_result = neighbor_re[0][1][0]
                        # update the best solution by local search on shaken solution
                        if neighbor_cur_score - best_result_score > 0:
                            best_result = neighbor_cur_result
                            best_result_score = neighbor_cur_score

                    # checking if there exist adversarial examples
                    if best_result.goal_status == GoalFunctionResultStatus.SUCCEEDED:
                        return best_result

            # update the word saliency by best solution
            index_order_new, search_over_new = self.gradient_based_order(best_result.attacked_text)
            if index_order_new.all() == index_order.all():
                pass
            # find the new word saliency by a better solution, return to the first neighbor
            else:
                index_order = index_order_new
                i = 0

        return best_result

    @property
    def is_black_box(self):
            return False

    def extra_repr_keys(self):
        return ["wir_method"]

