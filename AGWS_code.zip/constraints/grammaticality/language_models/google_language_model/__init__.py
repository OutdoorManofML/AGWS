"""
Google Language Models:
-----------------------------

"""


from .google_language_model import (
    GoogleLanguageModel as Google1BillionWordsLanguageModel,
)
