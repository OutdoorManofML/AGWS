"""

TextAttack Command Package for Evaluation
------------------------------------------

"""


from .eval_model_command import EvalModelCommand
