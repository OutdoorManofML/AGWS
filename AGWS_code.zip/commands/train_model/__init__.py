"""

TextAttack Command Package for Training
----------------------------------------


"""

from .train_model_command import TrainModelCommand
