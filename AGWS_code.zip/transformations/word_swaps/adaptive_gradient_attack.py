"""
Greedy Word Swap with Word Importance Ranking
===================================================


When WIR method is set to ``unk``, this is a reimplementation of the search
method from the paper: Is BERT Really Robust?

A Strong Baseline for Natural Language Attack on Text Classification and
Entailment by Jin et. al, 2019. See https://arxiv.org/abs/1907.11932 and
https://github.com/jind11/TextFooler.
"""


from torch.nn.functional import softmax
from textattack.goal_function_results import GoalFunctionResultStatus
from textattack.search_methods import SearchMethod
from textattack.shared.validators import (
    transformation_consists_of_word_swaps_and_deletions,
)
from abc import ABC, abstractmethod
from collections import defaultdict
import os
import numpy as np
import torch
from textattack.shared import utils
from textattack.shared import AttackedText
import operator
from textattack.constraints.semantics.sentence_encoders import UniversalSentenceEncoder


class AdaptiveGradientbasedAttack(SearchMethod):
    """An attack that greedily chooses from a list of possible perturbations in
    order of index, after ranking indices by importance.

    Args:
        wir_method: method for ranking most important words
        model_wrapper: model wrapper used for gradient-based ranking
    """

    def __init__(self, wir_method="unk"):
        self.wir_method = wir_method
        self.sim_metric = torch.nn.CosineSimilarity(dim=1)
        self.use = UniversalSentenceEncoder()

    def normalize(self,n):
        n = np.array(n)
        n[n < 0] = 0
        s = np.sum(n)
        if s == 0:
            return np.ones(len(n)) / len(n)
        else:
            return n / s

    def _get_index_order(self, initial_text):
        """Returns word indices of ``initial_text`` in descending order of
        importance."""
        len_text = len(initial_text.words)
        if self.wir_method == "gradient":

            victim_model = self.get_victim_model()
            gradient_scores = np.zeros(initial_text.num_words)
            grad_output = victim_model.get_grad(initial_text.tokenizer_input)
            gradient = grad_output["gradient"]
            word2token_mapping = initial_text.align_with_model_tokens(victim_model)
            for i, word in enumerate(initial_text.words):
                matched_tokens = word2token_mapping[i]
                if not matched_tokens:
                    gradient_scores[i] = 0.0
                else:
                    ave_grad = np.mean(gradient[matched_tokens], axis=0)
                    gradient_scores[i] = np.linalg.norm(ave_grad, ord=2)

            index_scores = gradient_scores
            search_over = False
        else:
            raise ValueError(f"Unsupported WIR method {self.wir_method}")

        if self.wir_method != "random":
            index_order = (-index_scores).argsort()

        return index_order, search_over

    def object_function(self,x):
        '''aim function: the smaller the better'''
        # compute victim model's prediction score
        result, _ = self.get_goal_results([x.attacked_text])
        pre_score = result[0].score
        if 'modified_indices' in x.attacked_text.attack_attrs:
            modified_words = len(x.attacked_text.attack_attrs['modified_indices'])
            modified_score = 1 - (modified_words / len(x.attacked_text.words))
            fitness = modified_score*pre_score
        else:
            fitness = pre_score

        return fitness

    def perform_search(self, initial_result):
        attacked_text = initial_result.attacked_text

        # Sort words by order of importance
        index_order, search_over = self._get_index_order(attacked_text)
        i = 0
        cur_result = initial_result
        results = None
        while i < len(index_order) and not search_over:
            transformed_text_candidates = self.get_transformations(
                cur_result.attacked_text,
                original_text=initial_result.attacked_text,
                indices_to_modify=[index_order[i]],
            )
            i += 1
            if len(transformed_text_candidates) == 0:
                continue
            results, search_over = self.get_goal_results(transformed_text_candidates)
            results = sorted(results, key=lambda x: -x.score)
            # Skip swaps which don't improve the score
            if results[0].score > cur_result.score:
                cur_result = results[0]
            else:
                continue
            # If we succeeded, return the index with best similarity.
            if cur_result.goal_status == GoalFunctionResultStatus.SUCCEEDED:
                best_result = cur_result
                return best_result
            else:
                index_order_new, search_over_new = self._get_index_order(cur_result.attacked_text)
                if index_order_new.all() == index_order.all():
                    pass
                else:
                    index_order = index_order_new
                    i = 0
        return cur_result
    def check_transformation_compatibility(self, transformation):
        """Since it ranks words by their importance, GreedyWordSwapWIR is
        limited to word swap and deletion transformations."""
        return transformation_consists_of_word_swaps_and_deletions(transformation)

    @property
    def is_black_box(self):
        if self.wir_method == "gradient":
            return False
        else:
            return True

    def extra_repr_keys(self):
        return ["wir_method"]

def normalize(n):
    n = np.array(n)
    n[n < 0] = 0
    s = np.sum(n)
    if s == 0:
        return np.ones(len(n)) / len(n)
    else:
        return n / s
