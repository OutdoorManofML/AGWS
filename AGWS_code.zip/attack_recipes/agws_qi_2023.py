"""

AGWS = (Adaptive Gradient-based Word Saliency for Adversarial Texts Attack)

"""
from textattack import Attack
from textattack.constraints.pre_transformation import (
    InputColumnModification,
    StopwordModification,
)
from textattack.constraints.semantics.sentence_encoders import UniversalSentenceEncoder
from textattack.goal_functions import UntargetedClassification
from textattack.search_methods import AdaptiveGradientbasedAttack
from textattack.transformations import WordSwapHowNetAndWordNet
from .attack_recipe import AttackRecipe


class AGWSQi2023(AttackRecipe):
    """An implementation of the paper 'Adaptive Gradient-based Word Saliency for Adversarial Texts Attack'
        If you have any issue，please contract with the author by qiyupeng0714@163.com
        :)
    """
    @staticmethod
    def build(model_wrapper):
        transformation = WordSwapHowNetAndWordNet()
        input_column_modification = InputColumnModification(
            ["premise", "hypothesis"], {"premise"}
        )
        constraints = [StopwordModification()]
        constraints.append(input_column_modification)
        goal_function = UntargetedClassification(model_wrapper)
        search_method = AdaptiveGradientbasedAttack()
        return Attack(goal_function, constraints, transformation, search_method)
