"""
Greedy Word Swap with Word Importance Ranking
===================================================


When WIR method is set to ``unk``, this is a reimplementation of the search
method from the paper: Is BERT Really Robust?

A Strong Baseline for Natural Language Attack on Text Classification and
Entailment by Jin et. al, 2019. See https://arxiv.org/abs/1907.11932 and
https://github.com/jind11/TextFooler.
"""


from torch.nn.functional import softmax
from textattack.goal_function_results import GoalFunctionResultStatus
from textattack.search_methods import SearchMethod
from textattack.shared.validators import (
    transformation_consists_of_word_swaps_and_deletions,
)
from abc import ABC, abstractmethod
from collections import defaultdict
import os
import torch
from textattack.shared import AttackedText
import random
from textattack.constraints.semantics.sentence_encoders import UniversalSentenceEncoder
import numpy as np


class AdaptiveGradientbasedAttack(SearchMethod):
    """
        The source code of the paper ‘Adaptive Gradient-based Word Saliency for Adversarial Text Attacks’
    """

    def __init__(self, wir_method="adaptive gradient-based word saliency"):
        self.wir_method = wir_method
        self.lmd = 0.3
        self.eps = 10
        self.gama = 0.2
        self.max_try = 20
        self.window_size = 40
        self.sim_metric = torch.nn.CosineSimilarity(dim=1)
        self.use = UniversalSentenceEncoder()

    def normalize(self, n):
        n = np.array(n)
        n[n < 0] = 0
        s = np.sum(n)
        if s == 0:
            return np.ones(len(n)) / len(n)
        else:
            return n / s

    def _get_best_neighbors(self, current_result, original_result):
        current_text = current_result.attacked_text
        neighbors_list = [[] for _ in range(len(current_text.words))]
        transformed_texts = self.get_transformations(
            current_text, original_text=original_result.attacked_text
        )
        # avoid repeat modified
        for transformed_text in transformed_texts:
            diff_idx = next(
                iter(transformed_text.attack_attrs["newly_modified_indices"])
            )
            neighbors_list[diff_idx].append(transformed_text)

        best_neighbors = []
        score_list = []
        for i in range(len(neighbors_list)):
            if not neighbors_list[i]:
                best_neighbors.append(current_result)
                score_list.append(0)
                continue

            neighbor_results, self._search_over = self.get_goal_results(
                neighbors_list[i]
            )
            if not len(neighbor_results):
                best_neighbors.append(current_result)
                score_list.append(0)
            else:
                neighbor_scores = np.array([r.score for r in neighbor_results])
                score_diff = neighbor_scores - current_result.score

                best_idx = np.argmax(neighbor_scores)
                best_neighbors.append(neighbor_results[best_idx])
                score_list.append(score_diff[best_idx])

        prob_list = self.normalize(score_list)

        return best_neighbors, prob_list

    def _perturb(self, pop_member, original_result):
        best_neighbors, prob_list = self._get_best_neighbors(
            pop_member, original_result
        )
        random_result = np.random.choice(best_neighbors, 1, p=prob_list)[0]
        pop_member.attacked_text = random_result.attacked_text
        pop_member = random_result

        return pop_member

    def gradient_based_order(self, initial_text):
        """Returns word indices of ``initial_text`` in descending order of
        importance."""
        victim_model = self.get_victim_model()
        gradient_scores = np.zeros(initial_text.num_words)
        grad_output = victim_model.get_grad(initial_text.tokenizer_input)
        gradient = grad_output["gradient"]
        word2token_mapping = initial_text.align_with_model_tokens(victim_model)
        for i, word in enumerate(initial_text.words):
            matched_tokens = word2token_mapping[i]
            if not matched_tokens:
                gradient_scores[i] = 0.0
            else:
                ave_grad = np.mean(gradient[matched_tokens], axis=0)
                gradient_scores[i] = np.linalg.norm(ave_grad, ord=2)

        index_scores = gradient_scores
        search_over = False
        index_order = (-index_scores).argsort()
        return index_order, search_over

    def get_similarity_score(self, transformed_texts, initial_text):
        embeddings_transformed_texts = self.use.encode(transformed_texts)
        embeddings_initial_text = self.use.encode(
            [initial_text] * len(transformed_texts)
        )

        if not isinstance(embeddings_transformed_texts, torch.Tensor):
            embeddings_transformed_texts = torch.tensor(embeddings_transformed_texts)

        if not isinstance(embeddings_initial_text, torch.Tensor):
            embeddings_initial_text = torch.tensor(embeddings_initial_text)

        scores = self.sim_metric(embeddings_transformed_texts, embeddings_initial_text)
        return scores

    # the evaluation function
    def object_function(self, x):
        re = []
        for j in range(len(x)):
            result, _ = self.get_goal_results([x[j]])
            #  self.get_goal_results() 返回 1-y_true的值
            pre_score = result[0].score
            if 'modified_indices' in x[j].attack_attrs:
                modified_words = len(x[j].attack_attrs['modified_indices'])
                modified_score = (modified_words / len(x[j].words))
                fitness = pre_score - self.lmd * modified_score
            else:
                fitness = pre_score
            tup = (fitness, result)
            re.append(tup)
        return re


    def perform_search(self, initial_result):
        n = len(initial_result.attacked_text.words)
        max_iter = n
        # Sort words by order of importance
        attacked_text = initial_result.attacked_text
        index_order, search_over = self.gradient_based_order(attacked_text)
        i = 0

        # initial result
        cur_result = initial_result
        best_result_score = self.object_function([initial_result.attacked_text])[0][0]
        best_result = self.object_function([initial_result.attacked_text])[0][1][0]
        # attack procedure

        while i < max_iter and not search_over:
            # Neighbor create
            transformed_text_candidates = self.get_transformations(
                cur_result.attacked_text,
                original_text=initial_result.attacked_text,
                indices_to_modify=[index_order[i]],
            )
            i += 1
            if len(transformed_text_candidates) == 0:
                continue
            # apply a local search to find a best solution in the i-th neighbors
            re = self.object_function(transformed_text_candidates)
            # checking if there exist adversarial examples
            results = []
            for r in range(len(re)):
                results.append(re[r][1])
            for result in results:
                if result[0].goal_status == GoalFunctionResultStatus.SUCCEEDED:
                    best_result = result[0]
                    return best_result
            new_re = sorted(re, key=lambda x: x[0], reverse=True)
            new_re_best = new_re[0]
            cur_result = new_re_best[1][0]
            use_score = self.get_similarity_score(
                [cur_result.attacked_text.text], initial_result.attacked_text.text
            )[0]
            cur_score = new_re_best[0] + self.gama * use_score
            if cur_score - best_result_score > 0:
                best_result = cur_result
                best_result_score = cur_score

            # apply Variable Neighborhood Search to find a better solution
            cnt = 0
            best_neighbors, prob_list = self._get_best_neighbors(
                cur_result, initial_result
            )
            while cnt < self.eps:
                cnt += 1
                random_index = random.randint(0, len(best_neighbors))
                # avoid repeated modification
                if random_index == i:
                    continue
                else:
                    new_neighbor_candidate = np.random.choice(best_neighbors, 1, p=prob_list)[0]
                    neighbor_re = self.object_function([new_neighbor_candidate.attacked_text])
                    neighbor_cur_result = neighbor_re[0][1][0]
                    neighbor_use_score = self.get_similarity_score([neighbor_cur_result.attacked_text.text], initial_result.attacked_text.text)[0]
                    neighbor_cur_score = neighbor_re[0][0] + self.gama * neighbor_use_score
                    # checking if there exist adversarial examples
                    if neighbor_cur_result.goal_status == GoalFunctionResultStatus.SUCCEEDED:
                        return neighbor_cur_result
                # update the best solution by local search on shaken solution
                if neighbor_cur_score - best_result_score > 0:
                    best_result = neighbor_cur_result
                    best_result_score = neighbor_cur_score

            # update the word saliency by best solution
            # cur_result = best_result
            index_order_new, search_over_new = self.gradient_based_order(best_result.attacked_text)
            index_order = index_order_new
            if index_order_new.all() == index_order.all():
                pass
            # find the new word saliency by a better solution, return to the first neighbor
            else:
                index_order = index_order_new
                i = 0
        return best_result

    @property
    def is_black_box(self):
            return False

    def extra_repr_keys(self):
        return ["wir_method"]

