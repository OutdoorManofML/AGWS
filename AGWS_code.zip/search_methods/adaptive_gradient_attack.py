"""

"""


from torch.nn.functional import softmax
from textattack.goal_function_results import GoalFunctionResultStatus
from textattack.search_methods import SearchMethod
from textattack.shared.validators import (
    transformation_consists_of_word_swaps_and_deletions,
)
from abc import ABC, abstractmethod
from collections import defaultdict
import os
import torch
from textattack.shared import AttackedText
import random
from textattack.constraints.semantics.sentence_encoders import UniversalSentenceEncoder
import numpy as np
np.random.seed(0)


class AdaptiveGradientbasedAttack(SearchMethod):
    """
        The source code of the paper ‘Adaptive Gradient-based Word Saliency for Adversarial Text Attacks’
    """

    def __init__(self, wir_method="adaptive gradient-based word saliency"):
        self.wir_method = wir_method
        self.lmd = 0.5  # in the paper, the author represent this value by alpha
        self.eps = 20   # in the paper, the author represent this value by T
        self.gama = 0.8  # in the paper, the author represent this value by lambda
        self.max_try = 3
        self.window_size = 40
        self.sim_metric = torch.nn.CosineSimilarity(dim=1)
        self.use = UniversalSentenceEncoder()

    def normalize(self, n):
        n = np.array(n)
        n[n < 0] = 0
        s = np.sum(n)
        if s == 0:
            return np.ones(len(n)) / len(n)
        else:
            return n / s

    def _get_best_neighbors(self, current_result, original_result):
        current_text = current_result.attacked_text
        neighbors_list = [[] for _ in range(len(current_text.words))]
        transformed_texts = self.get_transformations(
            current_text, original_text=original_result.attacked_text
        )
        # avoid repeat modified
        for transformed_text in transformed_texts:
            diff_idx = next(
                iter(transformed_text.attack_attrs["newly_modified_indices"])
            )
            neighbors_list[diff_idx].append(transformed_text)

        best_neighbors = []
        score_list = []
        for i in range(len(neighbors_list)):
            if not neighbors_list[i]:
                best_neighbors.append(current_result)
                score_list.append(0)
                continue

            neighbor_results, self._search_over = self.get_goal_results(
                neighbors_list[i]
            )
            if not len(neighbor_results):
                best_neighbors.append(current_result)
                score_list.append(0)
            else:
                neighbor_scores = np.array([r.score for r in neighbor_results])
                score_diff = neighbor_scores - current_result.score

                best_idx = np.argmax(neighbor_scores)
                best_neighbors.append(neighbor_results[best_idx])
                score_list.append(score_diff[best_idx])

        prob_list = self.normalize(score_list)

        return best_neighbors, prob_list

    def gradient_based_order(self, initial_text):
        """Returns word indices of ``initial_text`` in descending order of
        importance."""
        victim_model = self.get_victim_model()
        gradient_scores = np.zeros(initial_text.num_words)
        grad_output = victim_model.get_grad(initial_text.tokenizer_input)
        gradient = grad_output["gradient"]
        word2token_mapping = initial_text.align_with_model_tokens(victim_model)
        for i, word in enumerate(initial_text.words):
            matched_tokens = word2token_mapping[i]
            if not matched_tokens:
                gradient_scores[i] = 0.0
            else:
                ave_grad = np.mean(gradient[matched_tokens], axis=0)
                gradient_scores[i] = np.linalg.norm(ave_grad, ord=2)

        index_scores = gradient_scores
        search_over = False
        index_order = (-index_scores).argsort()
        return index_order, search_over

    def object_function(self, input_pre_result, initial_text):
        fitness = []
        for j in range(len(input_pre_result)):
            #  self.get_goal_results() can return the probability "1-y_true"
            pre_score = input_pre_result[j].score

            transformed_texts = [input_pre_result[j].attacked_text.text]
            embeddings_transformed_texts = self.use.encode(transformed_texts)
            embeddings_initial_text = self.use.encode(
                [initial_text] * len(transformed_texts)
            )

            if not isinstance(embeddings_transformed_texts, torch.Tensor):
                embeddings_transformed_texts = torch.tensor(embeddings_transformed_texts)

            if not isinstance(embeddings_initial_text, torch.Tensor):
                embeddings_initial_text = torch.tensor(embeddings_initial_text)
            use_score = self.sim_metric(embeddings_transformed_texts, embeddings_initial_text)

            if 'modified_indices' in input_pre_result[j].attacked_text.attack_attrs:
                modified_words = len(input_pre_result[j].attacked_text.attack_attrs['modified_indices'])
                modified_score = (modified_words / len(input_pre_result[j].attacked_text.words))
                score = pre_score - self.lmd * modified_score + self.gama * use_score
            else:
                score = pre_score + self.gama * use_score
            score = score.item()
            fitness.append(score)
        return fitness

    def perform_search(self, initial_result):
        n = len(initial_result.attacked_text.words)
        attacked_text = initial_result.attacked_text
        i = 0

        # initial result
        cur_result = initial_result
        best_result = cur_result
        best_result_score = 0

        # attack procedure
        # Sort words by order of importance
        index_order, search_over = self.gradient_based_order(attacked_text)
        # Local Search in i-th neighborhood structure
        while i < n and not search_over:
            transformed_text_candidates = self.get_transformations(
                best_result.attacked_text,
                original_text=initial_result.attacked_text,
                indices_to_modify=[index_order[i]],
            )
            i += 1
            if len(transformed_text_candidates) == 0:
                continue
            results, search_over = self.get_goal_results(transformed_text_candidates)
            fitness = self.object_function(results, initial_result.attacked_text.text)
            best_idx = np.argmax(fitness)
            cur_result_score = fitness[best_idx]
            cur_result = results[best_idx]

            if cur_result_score - best_result_score > 0:
                best_result = cur_result
                best_result_score = cur_result_score

            # Apply Random Shaking Step
            random_index = random.randint(0, n-1)
            cnt = 0
            while cnt < self.eps and not search_over:
                cnt += 1
                # avoid repeated modification
                if random_index == i:
                    continue
                else:
                    neighbors_candidates = self.get_transformations(
                        best_result.attacked_text,
                        original_text=initial_result.attacked_text,
                        indices_to_modify=[index_order[random_index]],
                    )
                    if len(neighbors_candidates) == 0:
                        continue
                    neighbors_results, search_over = self.get_goal_results(neighbors_candidates)
                    neighbor_fitness = self.object_function(neighbors_results, initial_result.attacked_text.text)
                    neighbor_best_idx = np.argmax(neighbor_fitness)
                    neighbor_best_result_score = neighbor_fitness[neighbor_best_idx]
                    neighbor_best_result = neighbors_results[neighbor_best_idx]

                    if neighbor_best_result.goal_status == GoalFunctionResultStatus.SUCCEEDED:
                        return neighbor_best_result

                    if neighbor_best_result_score - best_result_score > 0:
                        best_result = neighbor_best_result
                        best_result_score = neighbor_best_result_score

#            best_neighbors, prob_list = self._get_best_neighbors(best_result, initial_result)
#            best_result = np.random.choice(best_neighbors, 1, p=prob_list)[0]
#            best_result, search_over = self.get_goal_results([best_result.attacked_text])
#            best_result = best_result[0]

            # Update the word saliency
            if best_result.goal_status == GoalFunctionResultStatus.SUCCEEDED:
                return best_result

            index_order_new, search_over = self.gradient_based_order(best_result.attacked_text)

            if index_order_new.all() == index_order.all():
                pass
            else:
                index_order = index_order_new
                i = 0

        return best_result

    @property
    def is_black_box(self):
            return False

    def extra_repr_keys(self):
        return ["wir_method"]

